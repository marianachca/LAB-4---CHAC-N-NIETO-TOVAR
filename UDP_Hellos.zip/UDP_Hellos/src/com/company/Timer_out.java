package com.company;

import java.io.IOException;
import java.net.*;

public class Timer_out implements Runnable{

    Timer_out(int timeout_Seconds)throws SocketException, IOException, InterruptedException {
        timeout = timeout_Seconds;
        socket = new DatagramSocket();
        datagramPort = socket.getLocalPort();
        Thread thisThread = new Thread( this );
        thisThread.start();
    }
    public int getPort(){

        return datagramPort;
    }
    @Override
    public void run() {
        // create a standard reply message that indicates
        // the message came from the DatagramWatchdogTimer
        // in my case, a zero suffices.
        String replyStr = Integer.toString(0);
        byte[] replyBuff = new byte[ replyStr.length() ];
        replyStr.getBytes(0, replyStr.length(), replyBuff, 0);
        int replyLength = replyStr.length();
        // receive a message from the receiving thread.
        // this is necessary so we know how to send the unblocking
        // message back to it.
        byte[] buffer = new byte[128];
        DatagramPacket packet
                = new DatagramPacket( buffer, buffer.length );
        try {
            socket.receive( packet );
        } catch (IOException e) {
            e.printStackTrace();
        }
        // wait timeout number of seconds and then send an unblocking
        // message back.
        try {
            Thread.sleep( timeout* 1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int requestorPort = packet.getPort();
        InetAddress requestorAddress = packet.getAddress();
        DatagramPacket sendPacket
                = new DatagramPacket( replyBuff, replyLength,
                requestorAddress, requestorPort );
        DatagramSocket sendSocket
                = null;
        try {
            sendSocket = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        try {
            sendSocket.send( sendPacket );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private int timeout;
    private int datagramPort;
    private DatagramSocket socket;
}
