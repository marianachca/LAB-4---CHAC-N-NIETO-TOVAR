package com.company;

import java.io.IOException;
import java.net.*;
import java.lang.System.*;
import java.nio.charset.CharsetEncoder;
import java.util.Arrays;
import java.util.Timer;

public class Connection{

    public static int SYSTEM_PORT = 8011;
    public int timeout_seconds = 5;



    public Connection() throws SocketException, UnknownHostException, IOException, InterruptedException {

        DatagramSocket ClientSocket = new DatagramSocket();

        InetAddress inetAddress = InetAddress.getByName("localhost");





        //Storing Times
        long time_Sent;
        long time_Received;


        // Creating corresponding buffers
        byte[] sendingDataBuffer;
        byte[] receivingDataBuffer;

        // application code
        int timeoutSeconds = 5;
        InetAddress myAddress = InetAddress.getByName("");
        // create  an instance of the timer class
        Timer_out wdTimer = new Timer_out( timeoutSeconds );
        int wdPort = wdTimer.getPort();
        // send a message to wdTimer to get the timer started
        // msgBuff can be whatever you want.
        String msgString = "time me";
        byte[] msgBuff = new byte[ msgString.length() ];
        msgString.getBytes( 0, msgString.length(), msgBuff, 0 );
        DatagramSocket socket
                = new DatagramSocket();
        DatagramPacket wdPacket
                = new DatagramPacket( msgBuff, msgBuff.length, myAddress, wdPort );
        socket.send( wdPacket );
// now you can read from the socket and have some assurance
// that you will only block for timeoutSeconds.
        byte[] buffer = new byte[1024];
        DatagramPacket packet =
                new DatagramPacket( buffer, buffer.length,inetAddress,SYSTEM_PORT);
        socket.receive( packet );
        if(myAddress.equals(packet.getAddress()))
        {
            // received message from timer object
            System.out.println("Timed out");
        }
        else
        {
            // received a real message
            //Loop for pinging
            for (int numero_Secuencia = 1; numero_Secuencia < 11; numero_Secuencia++) {

            /* Converting data to bytes and
      storing them in the sending buffer */
                String sentence = "Ping " + numero_Secuencia;
                sendingDataBuffer = sentence.getBytes();
                receivingDataBuffer = sendingDataBuffer;

                //DatagramPacket timerPacket = new DatagramPacket(sendingDataBuffer,sendingDataBuffer.length,inetAddress,TimerPort);
                DatagramPacket sendingPacket = new DatagramPacket(sendingDataBuffer, sendingDataBuffer.length, inetAddress, SYSTEM_PORT);

                System.out.println("Sending message...");

                // sending UDP packet to the server
                ClientSocket.send(sendingPacket);
                time_Sent = System.nanoTime();

                // Get the server response .i.e. capitalized sentence
                DatagramPacket receivingPacket = new DatagramPacket(receivingDataBuffer, receivingDataBuffer.length);
                ClientSocket.receive(receivingPacket);
                time_Received = System.nanoTime();

                long RTT = (time_Received - time_Sent) / 1000000;
                String receivedData = new String(receivingPacket.getData());
                System.out.println("Sent from the server: " + receivedData + " " + RTT + " ms");
            }
        }




        // Closing the socket connection with the server
        ClientSocket.close();
    }
}
