package com.company;

import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Main {

    public static void main(String[] args){
	// write your code here
        try {
            new Connection();

        } catch(SocketException e){
            System.out.println(e.getMessage());
        } catch(UnknownHostException e){
            System.out.println(e.getMessage());

        } catch (IOException e){
            System.out.println(e.getMessage());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
