package com.company;

import java.io.IOException;
import java.net.*;
import java.lang.System.*;

public class Connection{

    public static int SYSTEM_PORT = 8011;



    public Connection() throws SocketException, UnknownHostException, IOException {

        // Instantiate a new DatagramSocket to receive responses from the client
        DatagramSocket serverSocket = new DatagramSocket(SYSTEM_PORT);


        // Creating corresponding buffers
        byte[] sendingDataBuffer;
        byte[] receivingDataBuffer = new byte[128];


        /* Instantiate a UDP packet to store the
      client data using the buffer for receiving data*/
        DatagramPacket inputPacket = new DatagramPacket(receivingDataBuffer, receivingDataBuffer.length);
        System.out.println("Waiting for a client to connect...");
        for (int i = 1; i < 11 ; i++) {

            // Receive data from the client and store in inputPacket
            serverSocket.receive(inputPacket);

            // Printing out the client sent data
            String receivedData = new String(inputPacket.getData());
            System.out.println("Sent from the client: "+receivedData);

            /*
             * Convert client sent data string to upper case,
             * Convert it to bytes
             *  and store it in the corresponding buffer. */
            sendingDataBuffer = receivedData.toUpperCase().getBytes();


            // Obtain client's IP address and the port
            InetAddress senderAddress = inputPacket.getAddress();
            int senderPort = inputPacket.getPort();

            // Create new UDP packet with data to send to the client
            DatagramPacket outputPacket = new DatagramPacket(
                    sendingDataBuffer, sendingDataBuffer.length,
                    senderAddress,senderPort
            );

            // Send the created packet to client
            serverSocket.send(outputPacket);

        }


        // Closing the socket connection with the server if pings = 10
            serverSocket.close();

    }
}
